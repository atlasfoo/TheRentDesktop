create
    definer = uuvywdmg2p2x5tad@`%` procedure sp_login_sysuser(IN usrname varchar(50), IN ipswd varchar(100),
                                                              OUT roln varchar(15))
begin
	SELECT rol into roln from sysuser where user_name=usrname and pswd=aes_encrypt(ipswd, ipswd);
    if roln is null then
		set roln='DENEGADO';
	end if;
end;

