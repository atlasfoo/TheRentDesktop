create
    definer = uuvywdmg2p2x5tad@`%` procedure sp_new_cliente_email(IN idCliente int, IN email varchar(40))
BEGIN
	insert into Cliente_Email values (idCliente,email);
END;

