create
    definer = uuvywdmg2p2x5tad@`%` procedure sp_agregar_reserva(IN id_client int, IN estados int, IN id_car int,
                                                                IN date_of_delivery date, IN date_of_receipt date,
                                                                IN cost double)
begin
	declare combstat varchar(20);
    if estados=1 then
		set combstat = 'RESERVADO';
	elseif estados=2 then
		set combstat = 'CANCELADO';
	elseif estados=3 then
		set combstat = 'PAGADO';
	end if;
    insert into Renta(Id_Cliente,Fecha,Estado) values(id_client,now(),combstat);
	insert into Detalle_Renta(Id_Renta,Id_Auto,Id_Empleado,Fecha_Entrega,Fecha_Recibo,Costo) 
					   values((select count(distinct Id_Renta)from Renta),id_car,(select count(distinct Id_Empleado)from Empleado),date_of_delivery,date_of_receipt,cost);
end;

