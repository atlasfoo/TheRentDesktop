create
    definer = uuvywdmg2p2x5tad@`%` procedure sp_new_renta(IN id_client int, IN estados int)
begin
	declare combstat varchar(20);
	if estados=1 then
		set combstat = 'RESERVADO';
	elseif estados=2 then
		set combstat = 'CANCELADO';
	elseif estados=3 then
		set combstat = 'PAGADO';
	end if;
    insert into Renta(Id_Cliente,Fecha,Estado) values(id_client,now(),combstat);
end;

