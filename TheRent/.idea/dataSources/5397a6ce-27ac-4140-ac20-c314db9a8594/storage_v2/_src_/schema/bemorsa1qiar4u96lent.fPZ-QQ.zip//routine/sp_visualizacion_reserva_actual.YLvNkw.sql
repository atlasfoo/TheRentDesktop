create
    definer = uuvywdmg2p2x5tad@`%` procedure sp_visualizacion_reserva_actual()
begin
	declare fecha_actual date;
    declare contador int;
    declare iterador int ;
    declare dato date;
    set contador = (select count(*) from Detalle_Renta);
    set fecha_actual = now();
    set iterador = 0 ;
	while iterador < contador do 
    set dato = (select dr.Fecha_Entrega from Detalle_Renta dr where dr.Id_Detalle_Renta = iterador);
    if dato >= fecha_actual then
    select
    concat(c.Primer_Nombre , ' ' , c.Segundo_Nombre)  as 'Nombres',
	concat(c.Primer_Apellido , ' ' , c.Segundo_Apellido) as 'Apellidos',
	dr.Fecha_Recibo as 'Fecha de Recibido',
	MA.Marca as 'Marca del Auto',
	MA.Modelo as 'Modelo del Auto',
	dr.Costo as 'Costo de la Renta'
	from Renta r
	inner join Detalle_Renta dr
	on dr.Id_Renta = r.Id_Renta
	inner join Auto a
	on a.Id_Auto = dr.Id_Auto
	inner join Modelo_Auto MA
	on MA.Id_Modelo = a.Id_Modelo
	inner join Cliente c
	on c.Id_Cliente = r.Id_Cliente
    where dr.Id_Detalle_Renta = iterador
	group by r.Id_Renta;
    end if;
	end while;
end;

