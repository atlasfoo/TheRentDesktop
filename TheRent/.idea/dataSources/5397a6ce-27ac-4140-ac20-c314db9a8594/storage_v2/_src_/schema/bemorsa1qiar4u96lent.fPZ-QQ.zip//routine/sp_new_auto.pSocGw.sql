create
    definer = uuvywdmg2p2x5tad@`%` procedure sp_new_auto(IN placa varchar(10), IN no_c varchar(30), IN vin varchar(30),
                                                         IN color varchar(30), IN trans int, IN id_mod int)
begin
	declare transm varchar(20);
	if trans=1 then
		set transm='MANUAL';
	elseif trans=2 then
		set transm='AUTOMATICO';
	else
		set transm='MANUAL';
	end if;
    insert into Auto(Placa, Vin, Color, Transmisión, Id_Modelo, Estado, No_Chasis) values(placa, vin, color, transm, id_mod, 'DISPONIBLE', no_c);
end;

