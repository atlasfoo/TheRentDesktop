create
    definer = uuvywdmg2p2x5tad@`%` procedure sp_visualizacion_rentas_actuales()
    create temporary table Fecha_Actual(
IdFecha int primary key not null auto_increment,
Fecha date,
Estado varchar(60));

