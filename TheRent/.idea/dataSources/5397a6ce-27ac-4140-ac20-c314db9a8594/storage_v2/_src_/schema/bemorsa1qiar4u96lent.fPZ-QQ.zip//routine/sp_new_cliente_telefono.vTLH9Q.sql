create
    definer = uuvywdmg2p2x5tad@`%` procedure sp_new_cliente_telefono(IN idCliente int, IN Numero int)
BEGIN
	insert into Cliente_Telefono values(idCliente,Numero);
END;

