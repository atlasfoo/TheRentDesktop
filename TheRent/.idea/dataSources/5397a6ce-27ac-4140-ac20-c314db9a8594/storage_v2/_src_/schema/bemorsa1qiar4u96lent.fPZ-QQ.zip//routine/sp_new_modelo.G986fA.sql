create
    definer = uuvywdmg2p2x5tad@`%` procedure sp_new_modelo(IN marca varchar(30), IN modelo varchar(20),
                                                           IN mot varchar(20), IN comb int,
                                                           IN tipo_carroceria varchar(20), IN id_cat int)
begin
	declare combs varchar(20);
	if comb=1 then
		set combs='GASOLINA';
	elseif comb=2 then
		set combs='DIESEL';
	elseif comb=3 then
		set combs='HIBRIDO';
	else
		set combs='GASOLINA';
	end if;
    insert into Modelo_Auto(Marca, Modelo, Motorizacion, Combustible, Tipo_Carroceria, Id_Categoria) values(marca, modelo, mot, combs, tipo_carroceria, id_cat);
end;

