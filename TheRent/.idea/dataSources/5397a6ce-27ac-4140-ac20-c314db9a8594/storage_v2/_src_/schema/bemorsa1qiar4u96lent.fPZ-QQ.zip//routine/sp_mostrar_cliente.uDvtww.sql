create
    definer = uuvywdmg2p2x5tad@`%` procedure sp_mostrar_cliente()
BEGIN
select c.Primer_Nombre,c.Segundo_Nombre ,c.Primer_Apellido ,c.Segundo_Apellido,
c.Cedula,
c.Dirreccion,
c.Tipo_Cliente,
c.Estado
from Cliente c
order by Primer_Nombre asc;

END;

