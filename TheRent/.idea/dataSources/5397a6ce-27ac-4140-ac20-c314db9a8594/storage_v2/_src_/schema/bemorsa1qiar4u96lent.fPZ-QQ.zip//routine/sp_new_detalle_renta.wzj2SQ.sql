create
    definer = uuvywdmg2p2x5tad@`%` procedure sp_new_detalle_renta(IN id_rent int, IN id_car int, IN id_employees int,
                                                                  IN date_of_delivery date, IN date_of_receipt date,
                                                                  IN cost double)
begin
	insert into Detalle_Renta(Id_Renta,Id_Auto,Id_Empleado,Fecha_Entrega,Fecha_Recibo,Costo) 
					   values(id_rent,id_car,id_employees,date_of_delivery,date_of_receipt,cost);
end;

