create
    definer = uuvywdmg2p2x5tad@`%` procedure sp_buscar_reservas(IN dato_cliente varchar(50))
begin
 select 
concat(c.Primer_Nombre , ' ' , c.Segundo_Nombre)  as 'Nombres',
concat(c.Primer_Apellido , ' ' , c.Segundo_Apellido) as 'Apellidos',
dr.Fecha_Entrega as 'Fecha de Entrega', 
dr.Fecha_Recibo as 'Fecha de Recibido',
MA.Marca as 'Marca del Auto',
MA.Modelo as 'Modelo del Auto',
dr.Costo as 'Costo de la Renta'
from Renta r
inner join Detalle_Renta dr
on dr.Id_Renta = r.Id_Renta
inner join Auto a
on a.Id_Auto = dr.Id_Auto
inner join Modelo_Auto MA
on MA.Id_Modelo = a.Id_Modelo
inner join Cliente c
on c.Id_Cliente = r.Id_Cliente
where c.Primer_Nombre like CONCAT(Dato_cliente,'%')
or  c.Segundo_Nombre like CONCAT(Dato_cliente,'%') 
or  c.Primer_Apellido like CONCAT(Dato_cliente,'%') 
or  c.Segundo_Apellido like CONCAT(Dato_cliente,'%');
end;

