create
    definer = uuvywdmg2p2x5tad@`%` procedure sp_new_empleado(IN p_nom varchar(20), IN s_nom varchar(20),
                                                             IN p_apll varchar(20), IN s_apll varchar(20),
                                                             IN dir varchar(70), IN ced varchar(16), IN tel varchar(15),
                                                             IN correo varchar(50), OUT id_empl int)
begin
	insert into Empleado(Primer_Nombre, Segundo_Nombre, Primer_Apellido, Segundo_Apellido, Direccion, Cedula, Telefono, Correo) values(p_nom, s_nom, p_apll, s_apll, dir, ced, tel, correo);
    select Id_Empleado into id_empl from Empleado where Cedula=ced;
end;

