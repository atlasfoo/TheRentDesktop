create
    definer = uuvywdmg2p2x5tad@`%` procedure sp_new_cliente(IN primernombre varchar(20), IN segundonombre varchar(20),
                                                            IN primerapellido varchar(20),
                                                            IN segundoapellido varchar(20), IN cedula varchar(20),
                                                            IN direccion varchar(100), IN tipocliente varchar(20))
BEGIN
		insert into Cliente(Primer_Nombre,Segundo_Nombre,Primer_Apellido
		,Segundo_Apellido,Cedula,Dirreccion,Tipo_Cliente,Estado)
		values (primernombre,segundonombre,primerapellido,segundoapellido,cedula,direccion,tipocliente,'Habilitado');
END;

